# Developer Portfolio / Online CV — Complete Build Plan
### Neon Cyber-Tech Theme (inspired by the "Cyber of X" reference)

---

## 1. Design Direction Summary

**Concept:** "Terminal meets neon city." A dark, glass-and-glow interface where code and identity intersect — your portfolio should feel like booting into your own personal OS.

| Token | Value | Use |
|---|---|---|
| `--bg-void` | `#0A0A0F` | Page background |
| `--bg-panel` | `#12121A` | Cards, panels, nav |
| `--neon-pink` | `#FF1B6B` | Primary accent, CTAs, glows |
| `--neon-violet` | `#9D4EDD` | Secondary accent, gradients |
| `--neon-blue` | `#4EA8FF` | Tertiary accent — links, code highlights, "available" status |
| `--text-primary` | `#F5F5F7` | Headings, body |
| `--text-muted` | `#9A9AA5` | Captions, labels |
| `--line` | `#2A2A35` | Hairline dividers |

**Typography:**
- **Display (headings):** *Chakra Petch* or *Rajdhani* — condensed, slightly technical, sci-fi-adjacent without being cliché. Used bold, uppercase, tight tracking for hero/section titles.
- **Body:** *Inter* or *IBM Plex Sans* — clean, highly legible at small sizes.
- **Monospace (code, labels, meta):** *JetBrains Mono* or *IBM Plex Mono* — used for eyebrows, tech tags, terminal snippets, timestamps ("`// 01 — about`").

**Signature element:** A "scanline / glitch" hero treatment — your name renders with a subtle chromatic-aberration glitch on load, then settles; a thin animated pink scanline periodically sweeps down the hero on scroll-idle. This one moment carries the "cyber" identity; everything else stays disciplined and quiet.

**Spacing & shape:** 8px base grid (8/16/24/32/64/96). Cards use 12–16px radius with a 1px `--line` border and a soft neon glow on hover (`box-shadow` in pink/violet at low opacity). Buttons are pill-shaped, matching your reference's rounded CTA.

**Icons:** Lucide or Phosphor (thin/duotone line icons) — recolor active/hover states to neon pink or violet. Avoid flat filled icon sets; line icons hold the cyber-glass mood better.

---

## 2. Sitemap

```
/                         Home (Landing)
/about                    About / Bio
/projects                 Projects (Grid/Filterable)
/projects/[slug]           └─ Individual Project Case Study
/experience               Experience & Timeline (work + education)
/skills                   Skills / Tech Stack (can also be a Home section)
/certifications           Certificates & Achievements
/blog                     Blog / Writing (optional, if you write)
/blog/[slug]               └─ Individual Post
/resume                   Resume / CV (viewable + downloadable)
/contact                  Contact
/404                      Not Found (themed)
```

For a single-developer portfolio, **Home, About, Projects, Experience, Skills, Contact** can live as anchored sections on one long-scroll page (SPA-style), with **Project Case Studies**, **Resume**, and **Blog** as separate routes. This hybrid is the most common pattern in modern portfolios: fast first impression via scroll, but deep content still gets its own URL for SEO and sharing.

---

## 3. Pages, Purpose & Sections

### 3.1 Home / Landing (`/`)
**Purpose:** Hook the visitor in 3 seconds, communicate who you are, what you do, and where to go next.

1. **Navbar** — logo/initials mark, links (Home / About / Projects / Experience / Contact), theme toggle, resume download button, mobile hamburger.
2. **Hero Section**
   - Eyebrow label: `// available for work` (blinking cursor / status dot in neon blue).
   - Glitch-in animated name + role (e.g., "Full-Stack Developer / Building fast, accessible web apps").
   - One-line value proposition.
   - Primary CTA ("View Projects") + Secondary CTA ("Download CV").
   - Right side: your photo/avatar (cut-out with pink/violet rim-light, like the reference's rim-lit rabbit-ear character) or an animated code/terminal visual, or a 3D avatar/blob.
   - Background: subtle particle field or animated grid/noise, low opacity, mouse-reactive parallax.
   - Scroll-down indicator (animated chevron or "scroll" text rotated 90°, matching reference's sidebar text).
3. **Quick Stats Strip** — mirrors your reference's bottom stat bar: e.g., "+5 Years Experience," "+30 Projects Shipped," "+12 Happy Clients," "GitHub Streak." Animated count-up numbers on scroll-into-view.
4. **About Preview** — short bio teaser + "Read more" link to `/about`.
5. **Featured Projects** — 3–4 top project cards with hover-reveal previews, link to `/projects`.
6. **Skills Snapshot** — interactive tech-stack visualization (see §5.3).
7. **Experience Teaser / Timeline preview** — condensed 3-item timeline, link to full page.
8. **Testimonials / Recommendations** (if available) — carousel of quotes from colleagues/clients (LinkedIn recommendations work well here).
9. **CTA Band** — "Let's build something" banner leading to `/contact`.
10. **Footer** — social links, quick nav, email, copyright, back-to-top button.

### 3.2 About (`/about`)
- Extended bio / personal story (who you are, journey into dev, philosophy).
- Portrait or illustrated avatar with neon rim-light treatment.
- "Beyond code" section — interests/hobbies (humanizes you).
- Tools & workflow ("my setup") — editor, OS, keyboard, etc. (developers love this detail).
- Fun facts / personality strip (favorite stack, currently learning, currently reading).
- Optional: downloadable one-pager "about me" or link to resume.

### 3.3 Projects (`/projects`)
- Filter/sort bar: by tech stack, category (Web App / Mobile / Open Source / Design), or status.
- Search input.
- Grid of project cards: cover image/video loop on hover, title, tagline, tech tags, live-link + GitHub icons.
- Toggle: Grid view / List view.
- Pagination or infinite scroll.
- "Featured" pinned section at top.

### 3.4 Project Case Study (`/projects/[slug]`)
- Hero banner (project cover, title, role, timeframe, live link, repo link).
- Problem → Approach → Solution narrative structure.
- Tech stack badges.
- Screenshots / embedded video / interactive demo iframe.
- Key metrics/results (performance gains, users, etc.).
- Challenges & learnings section.
- Next/previous project navigation.

### 3.5 Experience (`/experience`)
- Vertical animated timeline: work history + education interleaved, alternating left/right on desktop, single column on mobile.
- Each node: company/school logo, role/degree, dates, bullet achievements, tech used.
- Filter toggle: Work / Education / All.
- Downloadable resume CTA at the end.

### 3.6 Skills (`/skills` or Home section)
- Categorized skill groups (Frontend, Backend, DevOps, Tools, Soft Skills).
- Interactive visualization options (pick one or combine — see §5.3):
  - Radar/spider chart per category.
  - Animated proficiency bars with % on hover.
  - "Constellation" node graph where skills connect to projects that used them (click a skill → filters `/projects`).
- Icon + label chips for quick scanning.

### 3.7 Certifications & Achievements (`/certifications`)
- Card grid: certificate image/badge, issuing org, date, verify link.
- Awards, hackathon wins, open-source contributions, speaking engagements.
- Optional GitHub contribution graph embed.

### 3.8 Blog (optional) (`/blog`, `/blog/[slug]`)
- List with cover image, title, excerpt, read-time, tags, date.
- Individual post: MDX-style rich content, code blocks with syntax highlighting + copy button, table of contents, share buttons, related posts.

### 3.9 Resume/CV (`/resume`)
- Embedded, styled, readable resume (not just a PDF dump) — same neon theme, print-optimized.
- "Download PDF" and "Print" buttons.
- Optionally: toggle between "Recruiter view" (condensed) and "Detailed view."

### 3.10 Contact (`/contact`)
- Contact form: name, email, subject, message, honeypot/spam protection.
- Direct info: email (copy-to-clipboard), location/timezone, availability status.
- Social/professional links as glowing icon buttons (GitHub, LinkedIn, X/Twitter, Dribbble, etc.).
- Optional: embedded calendar link (Calendly/Cal.com) for booking calls.
- Success/error states with themed toast notifications.

### 3.11 404 Page
- Themed "signal lost" / "connection error" screen matching the cyber aesthetic, with a CTA back home.

---

## 4. Functional & Interactive Features

**Core functionality**
- Dark/light mode toggle (dark = default/neon theme; light = clean alt theme) with persisted preference.
- Fully responsive nav with animated mobile drawer/overlay menu.
- Smooth scroll + scroll-spy (nav highlights current section).
- Resume download (PDF) tracked via analytics event.
- Contact form with validation, spam protection (honeypot + rate limiting), and email delivery (e.g., Resend/EmailJS/Formspree).
- Project filter/search with instant client-side filtering.
- GitHub API integration: live repo stats (stars, latest commit, pinned repos), contribution graph.
- CMS or JSON/MDX-driven content (projects, blog, experience) so you can update without touching code — Sanity, Contentful, or simple local MDX/JSON.
- Sitemap.xml + robots.txt auto-generation.
- Analytics (Plausible/GA4) + Web Vitals monitoring.

**Signature/creative features**
- Custom cursor: default cursor replaced with a glowing dot + trailing ring that morphs (scale/color) over links, buttons, and project cards.
- Particle / animated grid background in hero, mouse-reactive (parallax tilt on avatar/cards using mouse position).
- Command palette (⌘K) — quick "jump to section / project / contact" launcher, terminal-style, big value-add for a dev portfolio.
- Terminal/typing-effect intro line ("$ whoami" → animates into your name).
- Konami-code or hidden easter egg (small delight for other devs who find it).
- Live "currently building" widget pulling from GitHub's latest commit or a simple status API.
- Sound-optional UI micro-feedback (subtle click/hover sfx, off by default, toggle available) — nice-to-have, skip if you want to keep it minimal.
- Skill-to-project constellation graph (click a skill node → highlights/filters related projects).
- Scroll-triggered glitch/scanline accents on section transitions (used sparingly — signature moment, not everywhere).
- Copy-to-clipboard on email/contact details with a toast confirmation.
- Print-optimized resume stylesheet (so `/resume` prints cleanly without breaking the layout).

---

## 5. Modern UI/UX Animation & Motion Plan

Use **Framer Motion** (React) or **GSAP** for the more elaborate scroll choreography.

1. **Page load:** Staggered fade/slide-up for hero elements (eyebrow → headline word-by-word → subtext → CTAs → visual), 60–120ms stagger, ease `cubic-bezier(0.16, 1, 0.3, 1)`.
2. **Scroll reveals:** Sections fade/slide up 24px as they enter viewport (IntersectionObserver-driven, one-time trigger, `duration: 0.5–0.7s`).
3. **Hover micro-interactions:** Project cards lift (translateY -6px) + neon border glow intensifies + cover image slight scale (1.03–1.05).
4. **Magnetic buttons:** Primary CTAs subtly follow cursor within a small radius before snapping back — playful, on-brand for a "modern UI/UX" showcase piece.
5. **Number count-ups:** Stats animate from 0 to target when scrolled into view.
6. **Skill bars/radar:** Fill/draw animation on first view (SVG stroke-dashoffset or width transition).
7. **Timeline:** Nodes and connecting line draw progressively as user scrolls (SVG path animation).
8. **Page/route transitions:** Short cross-fade + slight scale (150–250ms) between routes, avoid anything longer that feels like it's blocking navigation.
9. **Reduced motion:** All of the above respect `prefers-reduced-motion` — fall back to simple opacity fades, no parallax/glitch.
10. **Custom cursor & particle background:** Both should pause/disable automatically on touch devices and under reduced-motion settings.

**Guiding principle:** one orchestrated hero moment (glitch-in + scanline) is your signature; keep the rest of the motion consistent, fast (200–500ms), and purposeful rather than decorative everywhere.

---

## 6. Accessibility Recommendations

- Maintain **WCAG AA contrast** — neon pink/violet on near-black generally passes for large text/UI, but verify body-text combinations with a contrast checker; use `--text-primary` (near-white) for body copy, not saturated neon, which can fail contrast and cause eye strain.
- Visible **keyboard focus states** (a glowing outline in `--neon-blue` works well thematically and is distinct from hover states).
- All interactive elements reachable via Tab in logical order; skip-to-content link at page top.
- `alt` text for all images/screenshots; ARIA labels for icon-only buttons (social icons, theme toggle, hamburger).
- Respect `prefers-reduced-motion` and `prefers-color-scheme`.
- Custom cursor and particle effects must not be the *only* way to perceive interactivity — always pair with standard hover/focus states.
- Form fields with associated `<label>`, inline error messaging (not color-only — pair with icon/text), and accessible success confirmation.
- Sufficient tap target sizes (min 44×44px) for mobile nav and buttons.
- Semantic HTML throughout (`<nav>`, `<main>`, `<header>`, `<section>`, heading hierarchy h1→h2→h3, no skipped levels).

---

## 7. SEO Best Practices

- Unique, descriptive `<title>` and meta description per page/route (e.g., "Jane Doe — Full-Stack Developer Portfolio").
- Open Graph + Twitter Card meta tags with a custom social preview image (your name, role, neon-branded card) for link sharing.
- Structured data: `Person` and `CreativeWork`/`SoftwareSourceCode` JSON-LD schema for you and your projects.
- Semantic, crawlable HTML — avoid rendering critical text only inside canvas/particle animations.
- Fast Core Web Vitals: lazy-load below-fold images/videos, optimize/compress hero media, use `next/image` or equivalent, code-split heavy animation libraries.
- Clean, human-readable URLs (`/projects/task-manager-app`, not `/projects?id=4`).
- `sitemap.xml` and `robots.txt` present and submitted to Search Console.
- Descriptive alt text doubles as SEO signal for project images.
- Internal linking: project pages link back to `/projects` and to related skills/tags.
- If adding `/blog`: this is your strongest ongoing SEO lever — regular posts on real technical topics outperform a static portfolio for search visibility over time.
- Canonical tags to avoid duplicate-content issues if content is ever syndicated.

---

## 8. Responsive Design Notes

| Breakpoint | Layout behavior |
|---|---|
| **Desktop (≥1200px)** | Full multi-column hero (text + visual side-by-side), 3–4 col project grid, alternating timeline. |
| **Tablet (768–1199px)** | Hero stacks or shrinks visual, 2-col project grid, timeline collapses to single column with left-aligned nodes. |
| **Mobile (<768px)** | Single column everything, hamburger nav w/ full-screen overlay, stat strip becomes horizontal scroll or 2×2 grid, custom cursor disabled (touch), particle background simplified/removed for performance, sticky bottom "Contact / Resume" quick-action bar optional. |

Use fluid type (`clamp()`) and fluid spacing so headline sizes scale smoothly rather than jumping at breakpoints.

---

## 9. Suggested Tech Stack

- **Framework:** Next.js (React) — SSR/SSG for SEO, file-based routing fits the sitemap above.
- **Styling:** Tailwind CSS + CSS variables for the neon token system.
- **Animation:** Framer Motion (component/page transitions) + GSAP/ScrollTrigger (complex scroll choreography, SVG path draws).
- **Content:** MDX or a headless CMS (Sanity/Contentful) for projects & blog so content updates don't require redeploys.
- **Forms/Email:** Formspree, Resend, or EmailJS.
- **Hosting:** Vercel or Netlify (both pair natively with Next.js + give free web analytics).
- **Icons:** Lucide-react or Phosphor Icons.
- **Fonts:** Chakra Petch/Rajdhani (display) + Inter (body) + JetBrains Mono (meta/code), all via Google Fonts or self-hosted for performance.

---

## 10. User Flow Summary

```
Land on Home
  → glitch-in hero grabs attention (3–5s)
  → scroll: stats build credibility
  → scroll: about teaser builds trust
  → scroll: featured projects spark interest
     → click project → case study → back or next project
  → scroll: skills show technical depth
  → scroll: experience shows career trajectory
  → scroll: testimonials build social proof
  → CTA band → Contact
     → form submit → success toast → done
  (parallel path any time via nav/⌘K: jump straight to Projects, Resume download, or Contact)
```

---

A full low-fidelity wireframe (page-by-page layout blueprint) is provided as a separate interactive file so you can click through Home, About, Projects, Case Study, Experience, and Contact and see exactly where each element sits at desktop, tablet, and mobile widths.
